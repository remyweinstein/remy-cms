-- phpMyAdmin SQL Dump
-- version 3.5.0
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 29 2015 г., 14:46
-- Версия сервера: 5.1.62-community
-- Версия PHP: 5.3.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `remycms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `web_albums`
--

CREATE TABLE IF NOT EXISTS `web_albums` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `pic_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `web_catalog_cats`
--

CREATE TABLE IF NOT EXISTS `web_catalog_cats` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(5) NOT NULL,
  `is_parent` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `web_catalog_cats`
--

INSERT INTO `web_catalog_cats` (`id`, `title`, `url`, `content`, `picture`, `parent`, `is_parent`, `active`) VALUES
(1, 'Комплекты', 'komplekty', '', '', 0, 0, 1),
(2, 'Бюстгальтеры', 'byustgaltery', '', '', 0, 0, 1),
(3, 'Трусики', 'trusiki', '', '', 0, 0, 1),
(4, 'Купальники', 'kupalniki', '', '', 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `web_catalog_items`
--

CREATE TABLE IF NOT EXISTS `web_catalog_items` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` int(4) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `old_price` float NOT NULL,
  `annotation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `pic_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` int(1) NOT NULL,
  `country` int(2) NOT NULL,
  `new` int(1) NOT NULL,
  `favorite` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `web_catalog_items`
--

INSERT INTO `web_catalog_items` (`id`, `url`, `category`, `title`, `price`, `old_price`, `annotation`, `content`, `pic_url`, `active`, `country`, `new`, `favorite`) VALUES
(5, 'biryuzovyi_komplekt', 1, 'Бирюзовый комплект нижнего белья ', 3500, 5000, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '187448_684310.jpg', 1, 3, 0, 1),
(6, 'rozovyi_komplekt', 1, 'Розовый комплект нижнего белья', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '559527_529338.jpg', 1, 3, 0, 0),
(7, 'tsvetnoy_komplekt', 1, 'Цветной комплект нижнего белья', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '663373_bIMG_5668.jpg', 1, 1, 0, 0),
(8, 'sirenevyi_komplekt', 1, 'Сиреневый комплект нижнего белья', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '982221_large_komplekt-nizhnego-belya-ot-victorias-secret-84918.jpg', 1, 3, 0, 0),
(9, 'cherno_rozovyi_komplekt', 1, 'Черно-розовый комплект нижнего белья ', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '590129_photo-U17194-P1121841-T1409166917-N1323094.jpeg', 1, 3, 0, 1),
(10, 'chernyi_komplekt', 1, 'Черный комплект нижнего белья', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '200618_w600+h800+m2+komplekt_niznego_belia_13_enl.jpg', 1, 3, 0, 0),
(11, 'chernyj-byustgalter', 2, 'Черный бюстгалтер', 1000, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '796559_097.jpg', 1, 2, 0, 0),
(12, 'biryuzovyj-byustgalter', 2, 'Бирюзовый бюстгальтер', 1000, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '856655_306781-pic1.jpg', 1, 2, 1, 1),
(14, 'belyj-byustgalter', 2, 'Белый бюстгальтер', 1000, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '321200_foto_setru_ru-29-4315683.jpg', 1, 2, 0, 1),
(15, 'pushap-byustgalter', 2, 'Пушап бюстгальтер', 3500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '646801_liemenele_gilioms_iskirptems_16334_22535.jpg', 1, 1, 0, 0),
(16, 'zhenskie-trusiki-001', 3, 'Женские трусики', 500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '907643_tr1685z.jpg', 1, 1, 0, 1),
(17, 'zhenskie-trusiki-002', 3, 'Женские трусики', 500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '311147_zhenskoe-belyo.jpg', 1, 1, 0, 0),
(18, 'zhenskie-trusiki-003', 3, 'Женские трусики', 500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '655166_innamore-32002.jpg', 1, 1, 0, 0),
(19, 'zhenskie-trusiki-005', 3, 'Женские трусики', 500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '271417_776463-1.jpg', 1, 1, 0, 0),
(20, 'kupalnik-001', 4, 'Купальник', 4500, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '123817_VS-plavky-2009-Alessandra-Ambrosio_h29.jpg', 1, 6, 1, 0),
(21, 'kupalnik-002', 4, 'Купальник черный', 4000, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '787138_Jolidon.jpg', 1, 6, 1, 1),
(22, 'kupalnik-003', 4, 'Купальник вязанный', 4000, 0, 'This cute red and white polka dotted bikini features a banded halter top and matching bottom with tie sides.', '', '801169_0 (1).jpg', 1, 6, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `web_catalog_item_variants`
--

CREATE TABLE IF NOT EXISTS `web_catalog_item_variants` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `sku` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `id_item` int(6) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `old_price` float NOT NULL,
  `weight` float NOT NULL,
  `quantity` int(6) NOT NULL,
  `pic_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `web_catalog_item_variants`
--

INSERT INTO `web_catalog_item_variants` (`id`, `sku`, `id_item`, `name`, `price`, `old_price`, `weight`, `quantity`, `pic_url`) VALUES
(1, '43422', 5, 'XS', 3500, 5000, 0.5, 100, ''),
(2, '65533', 11, 'XS', 1000, 0, 0.3, 100, ''),
(3, '67555', 12, 'XS', 1000, 0, 0.3, 100, ''),
(4, '67555', 13, 'XS', 1000, 0, 0.3, 100, ''),
(5, '43988', 14, 'XS', 1000, 0, 0.3, 100, ''),
(6, '23456', 15, 'XS', 3500, 0, 0.3, 100, ''),
(7, '32444', 15, 'S', 3500, 0, 0.3, 100, ''),
(8, '32333', 15, 'M', 3500, 0, 0.3, 100, ''),
(9, '76555', 6, 'XS', 3500, 0, 0.5, 100, ''),
(10, '12321', 7, 'XS', 3500, 0, 0.5, 100, ''),
(11, '78988', 8, 'XS', 3500, 0, 0.5, 100, ''),
(12, '32222', 9, 'XS', 3500, 0, 0.5, 100, ''),
(13, '432552', 10, 'XS', 3500, 0, 0.5, 100, ''),
(14, '432200', 16, 'XS', 500, 0, 0.1, 100, ''),
(15, '213211', 17, 'XS', 500, 0, 0.1, 100, ''),
(16, '77666', 18, '', 500, 0, 0.1, 100, ''),
(17, '432553', 19, '', 500, 0, 0.1, 100, ''),
(18, '4325523', 20, 'XS', 4500, 0, 0.5, 100, ''),
(19, '908761', 21, 'XS', 4000, 0, 0.5, 100, ''),
(20, '123412', 22, 'XS', 4000, 0, 0.5, 100, '');

-- --------------------------------------------------------

--
-- Структура таблицы `web_country`
--

CREATE TABLE IF NOT EXISTS `web_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `web_country`
--

INSERT INTO `web_country` (`id`, `title`) VALUES
(1, 'Россия'),
(2, 'Китай'),
(3, 'Италия'),
(4, 'Испания'),
(5, 'Австрия'),
(6, 'Турция'),
(7, 'Швейцария'),
(8, 'Ю.Корея');

-- --------------------------------------------------------

--
-- Структура таблицы `web_modules`
--

CREATE TABLE IF NOT EXISTS `web_modules` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` text COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `system` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `web_modules`
--

INSERT INTO `web_modules` (`id`, `name`, `title`, `version`, `desc`, `author`, `system`, `active`) VALUES
(1, 'news', 'Новостной модуль', '0.1', 'Вставьте //news// если это Контент.', 'Remy Weinstein', 1, 1),
(2, 'gallery', 'Модуль Галерея', '0.1', 'Вставьте //gallery// если это Контент.', 'Remy Weinstein', 1, 1),
(3, 'menus', 'Модуль Меню', '1.0', 'Вывод меню, по умолчанию выводит заголовки родителя', 'Remy Weinstein', 1, 1),
(4, 'catalog', 'Каталог', '0.1', 'Модуль Каталога', 'Remy Weinstein', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `web_pages`
--

CREATE TABLE IF NOT EXISTS `web_pages` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(5) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `author` int(5) NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `view_menu` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL,
  `is_parent` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `web_pages`
--

INSERT INTO `web_pages` (`id`, `title`, `url`, `content`, `parent`, `date`, `author`, `template`, `view_menu`, `status`, `is_parent`) VALUES
(1, 'Lingerine Shop', 'index', '', 0, '2014-09-30 00:00:00', 1, 'default', 0, 1, 0),
(2, 'О нас', 'about', 'о нас', 0, '2015-06-29 09:52:51', 1, 'default', 1, 0, 0),
(3, 'Оплата', 'payment', '          ', 0, '2015-06-29 09:53:08', 1, 'default', 1, 0, 0),
(4, 'Доставка', 'delivery', '          ', 0, '2015-06-29 09:53:24', 1, 'default', 1, 0, 0),
(5, 'Контакты', 'contacts', '   <div class="title"><span>Контакты</span></div>\r\n      <div class="product_box">\r\n        <div id="contact_form">\r\n          <label class="contact_form">Имя:</label>\r\n          <input type="text" name="user" class="contact_input" />\r\n          <div class="cleardiv"></div>\r\n          <label class="contact_form">Email:</label>\r\n          <input type="text" name="payuity"  class="contact_input" />\r\n          <div class="cleardiv"></div>\r\n          <label class="contact_form">Сообщение:</label>\r\n          <textarea name="text" cols="" rows="" class="contact_textarea"></textarea>\r\n          <div class="cleardiv"></div><br><br>\r\n          <div class="button"><a href="#" onClick="submit();">Отправить</a></div>\r\n        </div>\r\n      </div>', 0, '2015-06-29 09:53:42', 1, 'default', 1, 0, 0),
(6, 'Условия доставки', 'terms-delivery', '          ', 0, '2015-06-29 09:54:03', 1, 'default', 1, 0, 0),
(7, 'Условия и правила', 'terms', '          ', 0, '2015-06-29 09:54:24', 1, 'default', 1, 0, 0),
(8, 'Политика безопасности', 'privacy', '          ', 0, '2015-06-29 09:54:46', 1, 'default', 1, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `web_pictures`
--

CREATE TABLE IF NOT EXISTS `web_pictures` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `album` int(5) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `pic_url` varchar(37) COLLATE utf8_unicode_ci NOT NULL,
  `author` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `web_settings`
--

CREATE TABLE IF NOT EXISTS `web_settings` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `lenght` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `web_settings`
--

INSERT INTO `web_settings` (`id`, `title`, `name`, `value`, `category`, `type`, `lenght`) VALUES
(1, 'Название сайта', 'main_name', 'Lingerine Shop', 'base', 'text', 20),
(2, 'Meta Title', 'var_meta_title', 'Lingerine Shop', 'base', 'text', 30),
(3, 'Meta Keys (по умолчанию)', 'var_meta_keys', '', 'base', 'text', 30),
(4, 'Meta Desc (по умолчанию)', 'var_meta_desc', '', 'base', 'text', 30),
(5, 'Включить регистрацию', 'disable_registration', '1', 'security', 'check', 1),
(6, 'Ширина иконок в галерее', 'res_thumb_width_gallery', '140', 'gallery', 'text', 3),
(7, 'Высота иконок в галерее', 'res_thumb_height_gallery', '140', 'gallery', 'text', 3),
(8, 'Максимальный размер картинки', 'max_size_content_image', '1048576', 'gallery', 'text', 7),
(9, 'Шаблон по умолчанию', 'default_template', 'default', 'system', 'text', 6),
(10, 'Почта no-reply', 'noreply_email', 'your@mail.box', 'system', 'text', 12),
(11, 'Почта поддержки', 'support_email', 'your@mail.box', 'system', 'text', 12),
(12, 'Ширина блока иконки', 'block_thumb_width_gallery', '140', 'gallery', 'text', 3),
(13, 'Высота блока иконки', 'block_thumb_height_gallery', '140', 'gallery', 'text', 3),
(14, 'Сервер IMAP(SSL)', 'mail_imap_server', 'imap.mail.ru', 'mail', 'text', 12),
(15, 'Порт IMAP сервера', 'mail_imap_server_port', '993', 'mail', 'text', 3),
(16, 'Почтовый ящик', 'mail_address_mail', 'your@mail.box', 'mail', 'text', 12),
(17, 'Пароль почтового ящика', 'mail_address_mail_pass', 'your_pass', 'mail', 'text', 12),
(18, 'Адрес Веб Интерфейса', 'mail_web_address', 'https://mail.webinterface/', 'mail', 'text', 12),
(19, 'Показывать админ панель', 'view_admin_panel', '1', 'system', 'check', 2),
(20, 'Адрес хоста', 'main_host', 'http://remy-cms.com/', 'base', 'text', 20),
(21, 'Страница не найдена', 'error_page', '404', 'system', 'text', 5),
(22, 'Папка с картинками', 'directory_pictures', 'uploads', 'gallery', 'text', 16);

-- --------------------------------------------------------

--
-- Структура таблицы `web_templates`
--

CREATE TABLE IF NOT EXISTS `web_templates` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` text COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `web_templates`
--

INSERT INTO `web_templates` (`id`, `name`, `title`, `version`, `desc`, `author`) VALUES
(2, 'default', 'Основной шаблон', '1.0', 'Основной шаблон Remy CMS', 'Remy CMS');

-- --------------------------------------------------------

--
-- Структура таблицы `web_users`
--

CREATE TABLE IF NOT EXISTS `web_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` int(1) NOT NULL DEFAULT '0',
  `date_reg` date NOT NULL,
  `date_last` datetime NOT NULL,
  `status` int(1) NOT NULL,
  `picture` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `new` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `web_users`
--

INSERT INTO `web_users` (`id`, `email`, `login`, `password`, `name`, `role`, `date_reg`, `date_last`, `status`, `picture`, `new`) VALUES
(1, 'admin@remy-cms.com', 'admin', '$2y$11$299f9e0b9e4e123d15502ucUvgG5vB2W2VjB2o8J62TRzR1wcFYaO', 'Админ', 3, '2014-11-25', '2014-12-31 04:43:00', 3, '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
